/*
 * The main code file for CMPSC 311 assignment 2.
 *
 * Implement your main function here.  See the assignment for full instructions.
 */

//Edited by Joshua Whitelaw (jnw5211@psu.edu)
#include <stdio.h>
#include "a2lib.h"

// Number of inputs to read.  You should test your code to be sure it works
// correctly with several different positive values of this constant (e.g., 1,
// 10, and 14).
#define NUM_INPUTS 14

/*
 * Main function for the "assign2" program.  This function reads in an array of
 * numbers and does a variety of processing on it.
 *
 * Parameters: none
 *
 * Return value: 0 if successful, 1 otherwise
 */
int main(void){
	// Declare your variables here
	int int_array[NUM_INPUTS];
	int i = 0;
	double double_array[NUM_INPUTS];

	// Read integer values into an array from standard input
	for (i = 0; i < NUM_INPUTS; i++) {
		scanf("%d", &int_array[i]);
	}

	// Fill in the rest of your main function here :D
	
	//Test root_array [6b]
	if((root_array(int_array, double_array, NUM_INPUTS)) == 1){
		printf("PROGRAM STOPPED!  Reason: root_array detected negative integer value. \n");
		return 1;
	}

	//If the return value of root_array was not 1 (indicating failure), do the process of root_array [6b]
	else
		root_array(int_array, double_array, NUM_INPUTS);

	//Print the original integer array using print_int_table [6c]
	printf("Original Integer Array: \n");
	print_int_table(int_array, NUM_INPUTS);

	//Do seven_sort [6d]
	seven_sort(int_array, NUM_INPUTS);
	
	///Print seven_sort [6d]
	printf("Seven Sorted Integer Array: \n");
	print_int_table(int_array, NUM_INPUTS);

	//Do weighted_bitcount where the returned result replaces the lement of the integer array [6e]
	for(i = 0; i < NUM_INPUTS; i++)
		int_array[i] = weighted_bitcount(int_array[i]);

	//Print the new weighted_bitcount integer array [6e]
	printf("Weighted Bitcount Integer Array: \n");
	print_int_table(int_array, NUM_INPUTS);

	//Print the original (rooted) double array using print_dbl_table [6f]
	printf("Original Square Root Double Array: \n");
	print_dbl_table(double_array, NUM_INPUTS);

	//Do the updown_sum of the double array and print it's result [6g]
	printf("Up down sum of double array is: %9.2f\n\n", updown_sum(double_array, NUM_INPUTS));

	//Do round_quarter on the the double array [6h]
	for(i = 0; i < NUM_INPUTS; i++)
		double_array[i] = round_quarter(double_array[i]);

	//Print the new round_quarter double array [6h]
	printf("Round Quarter Integer Array: \n");
	print_dbl_table(double_array, NUM_INPUTS);

	//Print double array with print_vertical function [6i]
	printf("Double Array Printed Vertically: \n");
	print_vertical(double_array, NUM_INPUTS);

	// Program finished successfully
	return 0;
}
