//Edited by Joshua Whitelaw (jnw5211@psu.edu)
#include "a2lib.h"
#include <math.h>
#include <stdio.h>

//NOTE: I have included conditional statements for negative values
//	even though I know that the program must stop once root_array
//	begins to calculate the square roots of integer_array and a value
//	is negative

//Print an integer array in a tabular format of 5 columns
void print_int_table(int* arr, int l){
	int i = 0;

	for(i = 0; i < l; i++){
		printf("%11d ", arr[i]);

		if((i + 1) % 5 == 0)	//Since the table is 5 columns wide, we need to go to a new line
			printf("\n");
	}

	printf("\n\n");  //Make some white space for more printf statements
}

//Print a double array in a tabular format of 5 columns
void print_dbl_table(double* arr, int l){
	int i = 0;
	
	for(i = 0; i < l; i++){
		printf("%9.2f ", arr[i]);

		if((i + 1) % 5 == 0)	//Since the table is 5 columns wide, we need to go to a new line
			printf("\n");
	}

	printf("\n\n");  //Make some white space for more printf statements
}

//Returns the square root of the sent integer array
int root_array(int* arr, double* root, int l){
	int i = 0;

	for(i = 0; i < l; i++){
		if(arr[i] < 0){		//If an element in the integer array is negative, return 1 (failure)
			printf("Negative element.  root_array function failed!\n");
			return 1;
		}

		root[i] = sqrt((double)arr[i]);		//Take the square root of the ith element in the array
	}

	return 0;
}

//Bubble sorts the array by the placement of 7 in each element
void seven_sort(int* arr, int l){
	int i = 0, j = 0, temp = 0;

	for(i = 0; i < l; i++){		//Modified bubble sort
		for(j = 0; j < (l - 1); j++){
			if((arr[j+1]) % 10 == 7){	//If the next element ends in a 7
				if((arr[j]) % 10 == 7){		//If the element before the next ends in a 7
					if(arr[j] > arr[j+1]){	//Check to see if they are in ascending order
						temp = arr[j+1];//and if not, switch the elements
						arr[j+1] = arr[j];
						arr[j] = temp;
					}
				}

				else{	//Else switch the elements
					temp = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = temp;
				}
			}

			else if(arr[j] > arr[j+1] && ((arr[j]) % 10 != 7)){	//Place the elements in ascending order
				temp = arr[j+1];				//as long as the jth element does not end
				arr[j+1] = arr[j];				//in a 7
				arr[j] = temp;
			}
		}
	}
}

//Returns the weighted bit count of an integer
int weighted_bitcount(int num){
	int bitCount = 0, copy = num, numBits = 1, bitPlace = 1, i = 0;

	if(num == 0){	//If the passed integer is 0, then the weighted bitcount is 0
		return 0;
	}

	if(copy < 0)	//If the passed integer is less than 0, take the absolute value (or multiply by negative 1)
		copy *= -1;

	do{	//This will determine the number of binary bits needed to represent the integer
		if(bitPlace <= num){	//If the largest bitPlace holder of 2^(numBits), then the integer needs to
			numBits += 1;	//be represented by another bit
			bitPlace *= 2;
		}

		else	//Else, have the while condition kick in to evaluate to false
			bitPlace = 0;
	}while(bitPlace != 0);

	bitPlace = (int) pow(2.0, (double) numBits);	//Set bitPlace to 2^(numBits)

	for(i = numBits; i >= 0; i--)
	{
		if(bitPlace <= copy){		//If bitPlace can fit into copy, subtract it from copy (i.e. the bit at the ith place is 1)
			copy -= bitPlace;	//and add the weighted bitcount to it
			bitCount += i;
		}

		bitPlace /= 2;	//Set bitPlace to represent the decimal value of the bit in the (i -1)th place (i.e. 2^(i-1))
	}

	return bitCount;
}

//Takes the updown sum of the double array
double updown_sum(double* arr, int l){
	int i = 0;
	double upDownSum = 0;

	for(i = 1; i <= l; i++){
		if((i % 2) == 1)	//If i is an odd integer, add the ith element in the array
			upDownSum += arr[i-1];

		else		//Else subtract the ith element in the array
			upDownSum -= arr[i-1];
	}

	return upDownSum;
}

//Rounds the decimal to the nearest decimal quarter
double round_quarter(double number){
	double rounded = (int) (number * 100.0) % 100;	//Looks at only the decimal points of the passed double

	if(number > 0){	//If the passed double is positive
		if(rounded >= 87.5)
			rounded = 100.0;

		else if(rounded >= 62.5)
			rounded = 75.0;

		else if(rounded >= 37.5)
			rounded = 50.0;

		else if(rounded >= 12.5)
			rounded = 25.0;

		else
			rounded = 0.0;
	}


	else{		//If the passed double is negative
		if(rounded > 87.5)
			rounded = 100.0;

		else if(rounded > 62.5)
			rounded = 75.0;

		else if(rounded > 37.5)
			rounded = 50.0;

		else if(rounded > 12.5)
			rounded = 25.0;

		else
			rounded = 0.0;
	}

	return ((int) number + (rounded / 100.0));	//Return the original number with new decimal places
}

//Prints the double array in a verticle column
void print_vertical(double* arr, int l){
	int i = 0, j = 0, rows = 0;	//Rows that should already be allocated should be 4 (1 for sign, 1 for decimal point, 2 for decimal places)
	double max = fabs (arr[0]), copy = 0;

	for(i = 1; i < l; i++){		//Determines the maximum number in the array to allocate enough rows for the table
		if(max < fabs(arr[i]))	//We only want to work with positive values without changing the elements in the array
			max = fabs(arr[i]);
	}

	while(max >= 10){	//Loops to find out how many digits the double is (besides the decimal points) for the number of rows
		rows++;
		max /= 10;
	}

	for(i = 0; i < l; i++){		//Prints out the sign of the element of the double array
		if(arr[i] < 0)		//If the element is < 0, print a -
			printf("-");
		
		else			//Else print a space
			printf(" ");
	}

	printf("\n");	//Next line

	for(j = rows; j >= 0; j--){		//Prints the non decimal digits of the double array
		for(i = 0; i < l; i++){	
			copy = (int) fabs(arr[i]) % (int) pow(10.0, (double) (j + 1));		//Copy has the loop focus on the digit we want of the element

			if(((int)copy / (int) pow(10.0, (double) j))!= 0)
				printf("%d", ((int)copy / (int) pow(10.0, (double) j)));

			else{
				if(fabs(arr[i]) >= ((int) pow(10.0, (double) (j+1))))
					printf("0");

				else	//Else print a space
					printf(" ");

			}
		}
	
		printf("\n");	//Next line
	}

	for(i = 0; i < l; i++)	//Prints the decimal points
		printf(".");

	printf("\n");	//Next line

	for(j = 2; j >= 1; j--){	//Prints the last two decimal places of the element in the double array
		for(i = 0; i < l; i++){
			copy = fabs(arr[i]) * 100.00;	//Makes sure to only capture the last two decimal places
			copy = (int) copy % 100;
			copy = (int) copy % (int) pow(10.0, (double) j);

			printf("%d", ((int)copy / (int) pow(10.0, (double) (j - 1))));
		}

		printf("\n");	//Next line
	}

	printf("\n");  //Make some white space for more printf statements
}
// Fill me in!
