//Edited by Joshua Whitelaw (jnw5211@psu.edu)
#ifndef A2LIB_H
#define A2LIB_H

/*
 * CMPSC 311 Assignment 2 function prototypes.  Complete the declarations in
 * this file and implement the functions in the file a2lib.c.  If the function
 * should return a value or take arguments, you will need to change the
 * corresponding "void" in the prototype to whatever is needed.
 */																							


// Hint: printf will do all of the needed formatting for these two functions if
// you ask it nicely.
void print_int_table(int*, int);
void print_dbl_table(double*, int);	

int root_array(int* , double*, int);

// Hint: start by implementing a bubble sort, and then modify it appropriately.
// You may find it useful to write a helper function for the ordering.
void seven_sort(int*, int);

// Hint: functions for which you may find it useful to read the man page:
//   abs, fabs, floor, trunc
//   (you may or may not use all of these, depending on your implementation
//   choices)	
int weighted_bitcount(int);

double updown_sum(double*, int);

double round_quarter(double);

void print_vertical(double*, int);

#endif
