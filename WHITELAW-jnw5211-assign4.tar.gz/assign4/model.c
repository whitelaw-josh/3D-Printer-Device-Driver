#include <stdint.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include "driver.h"
#include "model.h"

const uint32_t FILE_FORM = 0x03113d6d;	//Magic Number to check to make sure file is right format

// Initializes an empty model with the given title
int model_init(struct model *md, const char *title)
{
	//Copys title into md->title with appropriate number of bits and checks to see
	//if copy command worked
	if(strncpy(md->title, title, TITLE_MAX) == NULL)
		return 1;

	//Initialize all parameters to 0/NULL
	md->width = 0;
	md->height = 0;
	md->depth = 0;
	md->nchunks = 0;
	md->chunks = NULL;
		
	return 0;
}

// Adds a chunk to the model
int model_add_chunk(struct model *md, const struct chunk *ck)
{
	//If chunks has not been allocated
	if(md->nchunks == 0){
		//Check to see if dimensions and coordinates and mat is valid
		if((((int)ck->width) <= 0) || (((int)ck->depth) <= 0) || (((int)ck->height) <= 0 || (ck->mat > 15)) /*|| (((int)ck->x) < 0) || (((int)ck->y) < 0) || (((int)ck->z) < 0)*/)
			return 1;

		md->nchunks += 1;	//Increment for one chunk to be added to model

		md->chunks = calloc(1, sizeof(ck));	//Allocate enough memory for one chunk

		if(md->chunks == NULL)	//Failed memory allocation
			return 1;
		
		//Add ck to chunks array, modify model dimensions
		md->chunks[0].width = ck->width;
		md->chunks[0].height = ck->height;
		md->chunks[0].depth = ck->depth;
		md->chunks[0].x = ck->x;
		md->chunks[0].y = ck->y;
		md->chunks[0].z = ck->z;
		md->chunks[0].mat = ck->mat;

		md->width = ck->x + ck->width;
		md->height = ck->y + ck->height;
		md->depth = ck->z + ck->depth;
	}
	
	//If chunks has already been allocated
	else{
		//Check to see if dimensions and coordinates are valid and mat is valid
		if((((int)ck->width) <= 0) || (((int)ck->depth) <= 0) || (((int)ck->height) <= 0 || (ck->mat > 15)) /*|| (((int)ck->x) < 0) || (((int)ck->y) < 0) || (((int)ck->z) < 0)*/)
			return 1;

		md->nchunks += 1;	//Increment for one chunk to be added to model

		md->chunks = realloc(md->chunks, ((int)md->nchunks)*sizeof(struct chunk));	//Reallocate enough memory for another chunk

		if(md->chunks == NULL)	//Check to see if there was a failure to realloc
			return 1;

		//Add ck to chunks array, modify model dimensions
		md->chunks[md->nchunks-1].width = ck->width;
		md->chunks[md->nchunks-1].height = ck->height;
		md->chunks[md->nchunks-1].depth = ck->depth;
		md->chunks[md->nchunks-1].x = ck->x;
		md->chunks[md->nchunks-1].y = ck->y;
		md->chunks[md->nchunks-1].z = ck->z;
		md->chunks[md->nchunks-1].mat = ck->mat;

		//Check to see if added chunk's width at x is greater than model width
		if((ck->width + ck->x) > md->width)
			md->width = (ck->width + ck->x);
	
		//Check to see if added chunk's height at y is greater than model height
		if((ck->height + ck->y) > md->height)
			md->height = (ck->height + ck->y)	;

		//Check to see if added chunk's depth at z is greater than model depth
		if((ck->depth + ck->z) > md->depth) 
			md->depth = ck->z + ck->depth;
	}

	return 0;
}

// Releases any resources allocated to the model
void model_destroy(struct model *md)
{
	md->title[0] = '\0';

	md->width = 0;
	md->height = 0;
	md->depth = 0;

	free(md->chunks);
	md->chunks = NULL;
}

// Loads model info from a 3DM file, overwriting any existing information
int model_load(struct model *md, const char *filename)
{
	int fd = 0;		//File descriptor
	uint32_t fileForm = 0, titleOffSet = 0, chunkOffSet = 0,  nChunks = 0;		//File Format #, Variables to store offset of title and chunks
	uint16_t length = 0, i = 0;		//Title Length, Counter, Number of Chunks
	struct chunk *ck = calloc(1, sizeof(struct chunk));	//Temporary chunk holder to send to model_add_chunk

	if((fd = open(filename, O_RDONLY, 0)) < 0){	//Open given filename and check that there are no errors
		model_destroy(md);
		free(ck);
		ck = NULL;
		if((close(fd)) != 0)
			return 1;

		return 1;
	}

	if((pread(fd, &fileForm, 4, ((off_t)0))) != 4){	//Read magic number and check for error
		model_destroy(md);
		free(ck);
		ck = NULL;
		if((close(fd)) != 0)
			return 1;

		return 1;
	}

	if(ntohl(fileForm) != FILE_FORM){	//Check to make sure magic number is in 3dm	
		model_destroy(md);
		free(ck);
		ck = NULL;
		if((close(fd)) != 0)
			return 1;

		return 1;
	}

	if((pread(fd, &length, 1, ((off_t)16))) != 1){	//Read in title length and check for error
		model_destroy(md);
		free(ck);
		ck = NULL;
		if((close(fd)) != 0)
			return 1;

		return 1;
	}

	if((pread(fd, &titleOffSet, 4, ((off_t)8))) != 4){	//Read in title offset and check for error
		model_destroy(md);
		free(ck);
		ck = NULL;
		if((close(fd)) != 0)
			return 1;

		return 1;
	}

	titleOffSet = ntohl(titleOffSet);		//Convert title offset

	//Make sure offset is past the 17 bytes for the header
	if(titleOffSet < 17){
		model_destroy(md);
		free(ck);
		ck = NULL;
		if((close(fd)) != 0)
			return 1;

		return 1;
	}

	//If length of title is greater than maximum alloted size of title
	if(length > TITLE_MAX){
		for(i = 0; i < TITLE_MAX; i++){
			if((pread(fd, &(md->title[i]), 1, ((off_t)(titleOffSet + i )))) != 1){	//Read in title and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}
		}

		md->title[TITLE_MAX] = '\0';	//Null terminate title
	}

	//If length is less than or equal to maximum alloted size of title
	else{
		for(i = 0; i < length; i++){
			if((pread(fd, &(md->title[i]), 1, ((off_t)(titleOffSet + i )))) != 1){	//Read in title and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}
		}
		
		md->title[length] = '\0';	//Null terminate title
	}

	if((pread(fd, &nChunks, 4, ((off_t)12))) != 4){		//Read in number of chunks and check for error
		model_destroy(md);
		free(ck);
		ck = NULL;
		if((close(fd)) != 0)
			return 1;

		return 1;
	}
	
	nChunks = ntohl(nChunks);
	
	//Makes sure there are chunks to read
	if(nChunks != 0){
		if((pread(fd, &chunkOffSet, 4, ((off_t)4))) != 4){	//Read in chunk offset and check for error
			model_destroy(md);
			free(ck);
			ck = NULL;
			if((close(fd)) != 0)
				return 1;

			return 1;
		}
	
		chunkOffSet = ntohl(chunkOffSet);
		//printf("Title offset: %d \n", titleOffSet);
		//printf("Chunk offset: %d \n", chunkOffSet);
		//Make sure offset is past the 17 bytes for the header
		if(chunkOffSet < 17){
			model_destroy(md);
			free(ck);
			ck = NULL;
			if((close(fd)) != 0)
				return 1;

			return 1;
		}

		//Load in the chunks from the file
		for(i = 0; i < nChunks; i++){
			if((pread(fd, &(ck->x), 2, ((off_t)(chunkOffSet + (i * 13))))) != 2){	//Read in chunk x coordinate and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}
			
			ck->x = ntohs(ck->x);	//Convert x coor	

			if((pread(fd, &(ck->y), 2, ((off_t)(chunkOffSet + 2 + (i * 13))))) != 2){	//Read in chunk y coordinate and check for error
					model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}

			ck->y = ntohs(ck->y);	//Convert y coor

			if((pread(fd, &(ck->z), 2, ((off_t)(chunkOffSet + 4 + (i * 13))))) != 2){	//Read in chunk z coordinate and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}

			ck->z = ntohs(ck->z);	//Convert z coor

			if((pread(fd, &(ck->width), 2, ((off_t)(chunkOffSet + 6 + (i * 13))))) != 2){	//Read in chunk  width and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}

			ck->width = ntohs(ck->width);	//Convert width

			if((pread(fd, &(ck->height), 2, ((off_t)(chunkOffSet + 8 + (i * 13))))) != 2){	//Read in chunk height and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}

			ck->height = ntohs(ck->height);	//Convert height

			if((pread(fd, &(ck->depth), 2, ((off_t)(chunkOffSet + 10 + (i * 13))))) != 2){	//Read in chunk depth and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}

			ck->depth = ntohs(ck->depth);	//Convert depth 

			if((pread(fd, &(ck->mat), 1, ((off_t)(chunkOffSet + 12 + (i * 13))))) != 1){	//Read in chunk material and check for error
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}
		
			//printf("X: %d	Y: %d	Z: %d	Width: %d	Height: %d	Depth: %d	Mat: %d \n",ck->x, ck->y, ck->z, ck->width, ck->height, ck->depth, ck->mat);

			//Send chunk to be added to model and check for errors
			if((model_add_chunk(md, ck)) != 0){
				model_destroy(md);
				free(ck);
				ck = NULL;
				if((close(fd)) != 0)
					return 1;

				return 1;
			}
		}
	}

	if((close(fd)) != 0)	//Close the given filename and check that there are no errors
		return 1;

	//Free up temp chunk struct
	free(ck);
	ck = NULL;	

	//Set variables to 0
	fd = 0;
	fileForm = 0;
	titleOffSet = 0;
	chunkOffSet = 0;
	length = 0;
	i = 0;
	nChunks = 0;

	return 0;
}

// Prints model at layer Z=0 on an attached and powered-on TipTap
int model_print(struct model *md, struct tiptap *tt, uint16_t x, uint16_t y)
{
	uint16_t i = 0, j = 0, k = 0, l = 0;
	uint8_t *matLayer = calloc((md->width * md->height), sizeof(uint8_t));	//Array used for materials layer (calloced so to take care of empty spaces
	if(matLayer == NULL)	//Check to see if allocation was success
				return 1;

	//Send nozzle to printing coordinates at appropriate Z-axis starting position
	tiptap_moveto(tt, x, y, 1);

	//Printing All Layers
	for(i = 0; i < md->depth; i++){
			//Set up matlayer
			for(j = 0; j < md->nchunks; j++){
				//printf("Z: %d	Depth: %d	Width:%d	Mat: %d	Chunk#: %d	Z+Depth:%d\n", md->chunks[j].z, md->chunks[j].depth, md->chunks[j].width, md->chunks[j].mat, j, md->chunks[j].z + md->chunks[j].depth);
				//Make sure chunk is on appropriate layer in terms of Z-axis
				if(md->chunks[j].z <= i && (md->chunks[j].z + md->chunks[j].depth - 1) >= i){
					//Increment for height of specific chunk
					for(k = 0; k < md->chunks[j].height; k++){
						//Increment for width of specific chunk
						for(l = 0; l < md->chunks[j].width; l++){
							//Place specific chunk materials in correct positions of materials array
							matLayer[(md->chunks[j].x + l) + (md->width * (md->chunks[j].y + k)) ] = md->chunks[j].mat;
						}
					}
				}
			}

			//Send print command to tiptap driver and error check
			if((tiptap_printlayer(tt, x, y, md->width, md->height, matLayer)) != 0)
				return 1;
			
			//Zero out materials array for next iteration
			for(j = 0; j < (md->width * md->height); j++)
				matLayer[j] = 0;
	}

	//Free up materials array and null terminate
	free(matLayer);
	matLayer = NULL;

	//Set variables to 0
	i = 0;	
	j = 0;
	k = 0;
	l = 0;

	return 0;
}

// BONUS: Saves model info to a 3DM file, overwriting it if it exists
int model_save(struct model *md, const char *filename)
{
	int fd = 0;		//File descriptor
	uint32_t i = 0, chunkOffSet = 17, titleOffSet = ((md->nchunks) * 13)+ 17;	//Counter, Chunk Offset (will written right after the 3DM header), Title Offset (will be written after all chunks are written to file)
	uint8_t length = 0;	//Title Length

	if((fd = open(filename, O_WRONLY | O_TRUNC | O_CREAT, 0)) < 0)	//Open given filename and check that there are no errors
		return 1;

	if((pwrite(fd, &FILE_FORM, 4, ((off_t)0))) != 4)	//Write file format to file and check for error
		return 1;

	if((pwrite(fd, &chunkOffSet, 4, ((off_t)4))) != 4)	//Write chunk offfset to file and check for error
		return 1;

	if((pwrite(fd, &titleOffSet, 4, ((off_t)8))) != 4)		//Write title offset to file and check for error
		return 1;

	if((pwrite(fd, &(md->nchunks), 4, ((off_t)12))) != 4)	//Write number of chunks to file and check for error
		return 1;

	//Calculate title length and do not include truncation
	while((md->title[length]) != '\0')
		length++; 

	if((pwrite(fd, &length, 1, ((off_t)16))) != 1)	//Write title length to file and check for error
		return 1;

	//Write chunks to file
	for(i = 0; i < md->nchunks; i++){
		if((pwrite(fd, &(md->chunks[i].x), 2, ((off_t)(chunkOffSet + (i * 13))))) != 2)	//Write chunk x coordinate and check for error
			return 1;

		if((pwrite(fd, &(md->chunks[i].y), 2, ((off_t)(chunkOffSet + 2 + (i * 13))))) != 2)	//Write chunk y coordinate and check for error
			return 1;

		if((pwrite(fd, &(md->chunks[i].z), 2, ((off_t)(chunkOffSet + 4+ (i * 13))))) != 2)	//Write chunk z coordinate and check for error
			return 1;

		if((pwrite(fd, &(md->chunks[i].width), 2, ((off_t)(chunkOffSet + 6 + (i * 13))))) != 2)	//Write chunk width and check for error
			return 1;

		if((pwrite(fd, &(md->chunks[i].height), 2, ((off_t)(chunkOffSet + 8 + (i * 13))))) != 2)	//Write chunk height and check for error
			return 1;

		if((pwrite(fd, &(md->chunks[i].depth), 2, ((off_t)(chunkOffSet + 10 + (i * 13))))) != 2)	//Write chunk depth and check for error
			return 1;

		if((pwrite(fd, &(md->chunks[i].mat), 1, ((off_t)(chunkOffSet + 12 + (i * 13))))) != 1)	//Write chunk material and check for error
			return 1;
	}

	//Write title to file
	for(i = 0; i < length; i++){
		if((pwrite(fd, &(md->title[i]), 1, ((off_t)(titleOffSet + i)))) != 1)		//Write character of title and check for error
			return 1;
	}

	if((close(fd)) != 0)	//Close the given filename and check that there are no errors
		return 1;

	//Set variables to 0
	fd = 0;
	i = 0;
	chunkOffSet = 0;
	titleOffSet = 0;
	length = 0;

	return 0;
}
