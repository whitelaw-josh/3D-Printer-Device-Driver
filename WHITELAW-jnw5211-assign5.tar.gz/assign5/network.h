#ifndef NETWORK_H
#define NETWORK_H

// Network interface for the TipTap 3-D printer
int tapctl(uint32_t insn, void *buf);

#endif
