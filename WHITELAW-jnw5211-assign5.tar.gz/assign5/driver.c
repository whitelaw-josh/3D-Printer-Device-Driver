/*
 * Source file for the TipTap driver.  This is where you will implement the
 * user-facing API (tiptap_*) for the TipTap, using the tapctl() hardware
 * interface to communicate with the device.
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "tiptap.h"
#include "driver.h"

//Make the 32 bit instruction to send to tapctl
int  makeInstruct(uint8_t op, uint8_t mat, uint16_t dist, uint8_t flags, uint32_t SN, void *buffer){
	uint32_t instruction = 0;	//32 bit instruction sent	
	int errorCheck = 0;	//Check to see what is returned by tapctl
	uint16_t distConv = 0;

	instruction |= op;	//Load 5 bit op code
	instruction = instruction << 4;

	instruction |= mat;	//Load 4 bit material code
	instruction = instruction << 9;

	if((int16_t)dist < 0){
		distConv = dist;		//Get rid of the extra bits
		distConv = distConv << 7;
		distConv = distConv >> 7;
		instruction |= distConv;	//Load negative 9 bit distance code
	}

	else
		instruction |= dist;	//Load 9 bit distance code

	instruction = instruction << 4;

	instruction |= flags;	//Load 4 bit flags
	instruction = instruction << 10;

	instruction |= SN;	//Load 10 bit sequence number

	errorCheck = tapctl(instruction, buffer);

	if(errorCheck != 0)	//Error
		return 1;

	return 0; //No error	
}

int tiptap_init(struct tiptap *tt)
{
	//Initialize buffer for width and height dimensions
	uint16_t *buffer = calloc(2, sizeof(uint16_t));

	//Error Checker
	int errorCheck = 0;		

	//Initialize values of the struct	
	tt->SN = 0;
	tt->flags = 0;
	tt->dist = 0;
	tt->mat = 0;
	tt->op = TT_POWERON;

	errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, buffer);
	
	if(errorCheck != 0)
		return 1;

	//Set coordinates and width and height dimensions
	tt->x = 0;
	tt->y = 0;
	tt->xMax = buffer[0] - 1;
	tt->yMax = buffer[1] - 1;
	free(buffer);
	buffer = NULL;
	tt->SN += 1;	

	//Second buffer to hold distance
	uint16_t *buffer2 = calloc(1, sizeof(uint16_t));
	
	//Obtain the depth of the pinter bed
	tt->flags = TTFLAG_PROBE;
	tt->op = TT_MOVEX;	//Need for probe, but will not move at all
	errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, buffer2);
	
	if(errorCheck != 0)
		return 1;

	//Set z coordinates and z dimensions
	tt->z = buffer2[0];
	tt->zMax = buffer2[0];
	free(buffer2);
	buffer2 = NULL;
	tt->flags = 0;
	tt->SN += 1;

	return 0;
}

void tiptap_destroy(struct tiptap *tt)
{
	//Reset everything
	tt->flags = 0;
	tt->dist = 0;
	tt->mat = 0;
	tt->op = TT_POWEROFF;

	makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);

	tt->SN = 0;
}

int tiptap_moveto(struct tiptap *tt, uint16_t x, uint16_t y, uint16_t z)
{	/*printf("X: %d	Y: %d \n", x, y);
	printf("Xmax: %d	Ymax: %d \n", tt->xMax, tt->yMax);*/
	//Error checker
	int errorCheck = 0;

	//Make sure it is powered on
	if(tt->op == TT_INVALID)
		return 1;	
	
	//Make sure coordinates are not outside of bed
	if(x > tt->xMax || y > tt->yMax || z > tt->zMax)
		return 1;	
	
	if(tt->x != x){
	//Move nozzle to x position
	tt->op = TT_MOVEX;

	if(abs((x - (tt->x))) > 254){	//Loops enough times so that the instruction to move covers the entire distance
		int i = 0, j = 0, neg = 0;
		uint32_t bit8 = 0;

		i = abs(((x - (tt->x))/254)) + 1;
		
		if((x - (tt->x)) < 0)
			neg = 1;

		for(j = 1; j <= i; j++){
			if(i != j){
				if(neg == 0)	//If distance is not negative
					tt->dist = 254;

				else	//If it is negative
					tt->dist = -254;

				errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);
			}

			else{
				if(neg == 0)	//If distance is not negative
					tt->dist = (x - (tt->x)) - bit8;

				else	//If it is negative
					tt->dist = (x - (tt->x)) + bit8;

				errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);
			}

			if(errorCheck != 0)
				return 1;

			//Make sure sequence number is representing correct number
			if(tt->SN == 1023)
				tt->SN = 0;

			else
				tt->SN += 1;
			
			bit8 += 254;	
		}
	}

	else{
		tt->dist = x - (tt->x);

		errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);

		if(errorCheck != 0)
			return 1;

		//Make sure sequence number is representing correct number
		if(tt->SN == 1023)
			tt->SN = 0;
		else
			tt->SN += 1;
	}

	tt->x = x;
	}
	
	if(tt->y != y){
	//Move nozzle to y position
	tt->op = TT_MOVEY ;

	if(abs((y - (tt->y))) > 254){	//Loops enough times so that the instruction to move covers the entire distance
		int i = 0, j = 0, neg = 0;
		uint32_t bit8 = 0;

		i = abs(((y - (tt->y))/254)) + 1;
		
		if((y - (tt->y)) < 0)
			neg = 1;

		for(j = 1; j <= i; j++){
			if(i != j){
				if(neg == 0)	//If distance is not negative
					tt->dist = 254;

				else	//If it is negative
					tt->dist = -254;

				errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);
			}

			else{
				if(neg == 0)	//If distance is not negative
					tt->dist = (y - (tt->y)) - bit8;

				else	//If it is negative
					tt->dist = (y - (tt->y)) + bit8;

				errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);
			}

			if(errorCheck != 0)
				return 1;

			//Make sure sequence number is representing correct number
			if(tt->SN == 1023)
				tt->SN = 0;
			
			else
				tt->SN += 1;

			bit8 += 254;	
		}
	}

	else{
		tt->dist = y - (tt->y);
		errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);

		if(errorCheck != 0)
			return 1;

		//Make sure sequence number is representing correct number
		if(tt->SN == 1023)
			tt->SN = 0;

		else
			tt->SN += 1;
	}

	tt->y = y;
	}

	if(tt->z != z){
	//Move nozzle to z position
	tt->op = TT_MOVEZ;

	if(abs((z - (tt->z))) > 254){	//Loops enough times so that the instruction to move covers the entire distance
		int i = 0, j = 0, neg = 0;
		uint32_t bit8 = 0;

		i = abs(((z - (tt->z))/254)) + 1;
		
		if((z - (tt->z)) < 0)
			neg = 1;

		for(j = 1; j <= i; j++){
			if(i != j){
				if(neg == 0)	//If distance is not negative
					tt->dist = 254;

				else	//If it is negative
					tt->dist = -254;

				errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);
			}

			else{
				if(neg == 0)	//If distance is not negative
					tt->dist = (z - (tt->z)) - bit8;

				else	//If it is negative
					tt->dist = (z - (tt->z)) + bit8;

				errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);
			}

			if(errorCheck != 0)
				return 1;

			//Make sure sequence number is representing correct number
			if(tt->SN == 1023)
				tt->SN = 0;
			
			else
				tt->SN += 1;

			bit8 += 254;	
		}
	}

	else{
		tt->dist = (z - (tt->z));
		errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, NULL);

		if(errorCheck != 0)
			return 1;

		//Make sure sequence number is representing correct number
		if(tt->SN == 1023)
			tt->SN = 0;
		else
			tt->SN += 1;
	}

	tt->z = z;
	}

	tt->dist = 0;
	return 0;
}

void tiptap_getpos(struct tiptap *tt, uint16_t *x, uint16_t *y, uint16_t *z)
{
	//Set values equal to the pointers
	x[0] = tt->x;
	y[0] = tt->y;
	z[0] = tt->z;
}

int tiptap_printlayer(struct tiptap *tt, uint16_t x, uint16_t y,
		uint16_t w, uint16_t h, const uint8_t *materials)
{
	//Check to see if powered on
	if(tt->op == TT_INVALID)
		return 1;

	//Check to make sure x, y are within boundaries
	if(x > tt->xMax || y > tt->yMax)
		return 1;

	//Start printing at x y coordinates
	if(tt->x != x || tt->y !=y)
		tiptap_moveto(tt, x, y, tt->z);

	//Check to make sure w, h are within boundaries
	if(((tt->x) + w) > tt->xMax + 1 || ((tt->y) + h) > tt->yMax + 1)
		return 1;

	//If the given width and height are zero
	if(w == 0 || h == 0)
		return 1;

	uint16_t i = 0, j = 0;
	int errorCheck = 0;
	int noPrint = 0;
	uint8_t *printedArray = calloc(w, sizeof(uint8_t));	//Going to keep track of what is already printed
	uint8_t *printingArray = calloc(w, sizeof(uint8_t));	//Going to keep track of what needs to be printed

	int l = 0;

	for(i = 0; i < h; i++){
		for(j = 0; j < w; j++){
			//printf("Row: %d   Column: %d\n", i, j);
			tt->mat = materials[(i*w)+j];
			//		printf("FOR MATERIALS : %d \n", tt->mat);

			if(tt->mat != 0){
				for(l = 0; l < w; l++){
					if(tt->mat == materials[(i*w)+l] && printedArray[l] != 1){	//For the material, if the material printed here is the same as before
						printingArray[l] = 1;				//and it has not been printed set the buffer array element to 1
						printedArray[l] = 1;
						noPrint = 0;
					}

					else if(printedArray[l] != 1)
						printingArray[l] = 0;	//Else 0
				}

				if(noPrint == 0){	//If we are actually printing something
					//printf("BEFORE PRINT: X: %d, Y: %d, Z: %d\n", tt->x, tt->y, tt->z);
					tt->flags = TTFLAG_EXTRUDE;
					tt->op = TT_MOVEX;
					//Need to print directly underneath and then probably move across entire width or something
					if((tt->x + w) > tt->xMax){
						//If printing width is greater than 253
						if(w > 253){
							int k = 0;

							//Loop through how many times 253 can fit into the width 
							for(k = 0; k < (w/253); k++){
								errorCheck = makeInstruct(tt->op, tt->mat, 253, tt->flags, tt->SN, &printingArray[(k*253)]);

								if(errorCheck != 0)	//Make sure instruction worked
									return 1;
							
								if(tt->SN == 1023)	//Make sure sequence number is represented correct
									tt->SN = 0;

								else
									tt->SN += 1;

								tt->x += 253;
							}
								
							//Print out remainder of width%253
							errorCheck = makeInstruct(tt->op, tt->mat, w%253, tt->flags, tt->SN, &printingArray[(w - (w%253))]);

							if(errorCheck != 0)	//Make sure instruction worked
									return 1;

							tt->x += (w%253) + 1;
						}

						else{
							errorCheck = makeInstruct(tt->op, tt->mat, w-1, tt->flags, tt->SN, printingArray);
							tt->x += w - 1;
						}

						if(errorCheck != 0)	//Make sure instruction worked
							return 1;

						tt->dist = 0;
						
						if(printingArray[w-1] != 0){
							if(tt->SN == 1023)	//Make sure sequence number is represented correct
								tt->SN = 0;

							else
								tt->SN += 1;

							errorCheck = makeInstruct(tt->op, tt->mat, 0, tt->flags, tt->SN, &printingArray[w-1]);
						}	
					}

					else{
						//If width is greater than 253, new printing method 
						if(w > 253){
							int k = 0;

							//Loop through how many times 253 can fit into the width 
							for(k = 0; k < (w/253); k++){
								errorCheck = makeInstruct(tt->op, tt->mat, 253, tt->flags, tt->SN, &printingArray[(k*253)]);

								if(errorCheck != 0)	//Make sure instruction worked
									return 1;
							
								if(tt->SN == 1023)	//Make sure sequence number is represented correct
									tt->SN = 0;

								else
									tt->SN += 1;

								tt->x += 253;
							}

							//Print out remainder of w%253
							errorCheck = makeInstruct(tt->op, tt->mat, w%253, tt->flags, tt->SN, &printingArray[(w - (w%253))]);

							if(errorCheck != 0)	//Make sure instruction worked
									return 1;
							
							tt->x += w%253;
						}

						else{
							errorCheck = makeInstruct(tt->op, tt->mat, w, tt->flags, tt->SN, printingArray);
							tt->x += w;
						}
					}
					
					//printf("AFTER PRINT: X: %d, Y: %d, Z: %d\n", tt->x, tt->y, tt->z);

					if(errorCheck != 0)	//Make sure instruction worked
						return 1;
					
					if(tt->SN == 1023)	//Make sure sequence number is represented correct
						tt->SN = 0;

					else	
						tt->SN += 1;

					tt->flags = 0;
					tt->mat = 0;
					tt->dist = 0;
					noPrint = 1;
				
					tiptap_moveto(tt, x, tt->y, tt->z);	//Done reset it back	

					for(l = 0; l < w; l++)
						printingArray[l] = 0;
				}				
			}		

			else
				printedArray[j] = 0;
		}

		for(j = 0; j < w; j++)
			printedArray[j]=0;

		tt->flags = 0;
		tt->mat = 0;
		tt->dist = 0;

		if(tt->y != tt->yMax)
			tiptap_moveto(tt, x, ((tt->y) + 1), tt->z);	//Move up one column
	}

	tt_log_layer(tt->z-1);

	free(printedArray);
	free(printingArray);
	//free(bigPrintingArray);
	printedArray = NULL;
	printingArray = NULL;	
	//bigPrintingArray = NULL;

	//Move the nozzle up one
	//Need to make sure you are ABLE to move it up
	if(((tt->z)+ 1) <= (tt->zMax))
		tiptap_moveto(tt, x, y, ((tt->z) + 1));
	
	return 0;
}

/* Bonus */
int tiptap_scan(struct tiptap *tt, uint16_t x, uint16_t y, uint16_t w, uint16_t h,
		uint16_t *output)
{
	//Start printing at x y coordinates
	tiptap_moveto(tt, x, y, tt->zMax);

	//Check if you cannot print anymore
	int errorCheck = 0, i = 0;

	for(i = 0; i < h; i++){
		tt->op = TT_MOVEX;
		tt->flags = TTFLAG_PROBE;
		tt->dist = w; 
		
		errorCheck = makeInstruct(tt->op, tt->mat, tt->dist, tt->flags, tt->SN, output);	//Scan a row for distance
		output += (i*w);		

		if(errorCheck != 0)
			return 1;

		//Make sure sequence number is representing correct number
		if(tt->SN == 1023)
			tt->SN = 0;

		tt->SN += 1;
		tt->x = x + w;
		tt->flags = 0;
		
		if(i != (h - 1))
			tiptap_moveto(tt, x, ((tt->y) + 1), tt->z);	//Reset but move up a column

		else
			tiptap_moveto(tt, x, y, tt->z);		//At the last row to scan, send back
	}
	output -= (w*h);

	return 0;
}
