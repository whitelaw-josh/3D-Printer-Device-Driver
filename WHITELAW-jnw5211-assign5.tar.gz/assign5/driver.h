#ifndef DRIVER_H
#define DRIVER_H

#include <stdint.h>
/*
 * Header file for the TipTap driver.  This file defines the types and functions
 * needed to implement a driver for the TipTap hardware.
 *
 * DO NOT put function implementations in this file, and DO NOT change the
 * function prototypes below!  The only thing you should need to change here is
 * to fill in the struct definition below with any state you want to keep track
 * of.
 */

struct tiptap {
	/* Store any needed driver state in this struct.  If you use global
	 * variables in a driver, it will stop working as soon as you connect a
	 * second device... so put them here instead!  This struct will be
	 * passed to each of the driver functions so you can read your state
	 * variables from it.
	 */
	uint32_t SN;	//Sequence
	uint8_t flags;	//Flags
	uint16_t dist;	//Distance
	uint8_t mat;	//Materials
	uint8_t op;	//Opcode
	uint16_t x;	//X coordinate
	uint16_t y;	//Y coordinate	
	uint16_t z;	//Z coordinate
	uint16_t xMax;	//X size of printer bed
	uint16_t yMax;	//Y size of printer bed
	uint16_t zMax;	//Z size of printer bed
};

int tiptap_init(struct tiptap *tt);

void tiptap_destroy(struct tiptap *tt);

int tiptap_moveto(struct tiptap *tt, uint16_t x, uint16_t y, uint16_t z);

void tiptap_getpos(struct tiptap *tt, uint16_t *x, uint16_t *y, uint16_t *z);

int tiptap_printlayer(struct tiptap *tt, uint16_t x, uint16_t y,
		uint16_t w, uint16_t h, const uint8_t *materials);

/* Bonus */
int tiptap_scan(struct tiptap *tt, uint16_t x, uint16_t y, uint16_t w, uint16_t h,
		uint16_t *output);

#endif
