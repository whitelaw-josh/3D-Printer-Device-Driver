#include<arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "network.h"
#include "tiptap.h"

//Function Prototypes
uint8_t returnOpCode(uint32_t);
uint8_t returnFlag(uint32_t);
uint16_t returnDist(uint32_t);
void makeWriteInsn(uint32_t, uint16_t *, size_t);
void makeWriteInsnPrnt(void *, uint8_t *, size_t);

// Variable to keep track of the socket file descriptor
static int sock = -1;

// Convenience function to sign-extend a 9-bit two's complement number into
// something bigger.  Takes the 9-bit version and returns a value suitable for
// storing in a signed integer of any sort.
int signextend_9bit(int nine_bit)
{
	if (nine_bit & (1L << 8))
		nine_bit |= ~((1L << 9) - 1);
	return nine_bit;
}

// Network interface for the TipTap 3-D printer
int tapctl(uint32_t insn, void *buf)
{
	uint8_t opcode = 0;		//Variable for getting opcode
	uint8_t flag = 0;		//Variable for getting flag
	uint16_t *writeInsn = NULL;	//Ptr for write instruction
	uint16_t *readInsn = NULL;	//Ptr for read instruction

	opcode = returnOpCode(insn);
	flag = returnFlag(insn);

	//If the instruction is to power on tiptaps printer	
	if(opcode == ((uint8_t)TT_POWERON)){
		struct sockaddr_in ttSock;	//Socket for tiptap

		//Get the converted IPv4 address and check for error
		if((inet_aton(TIPTAP_IP, &(ttSock.sin_addr))) == 0){
			perror("FAILED: inet_aton call");
			return 1;
		}

		//Set ttSock struct's domain and properly converted port
		ttSock.sin_family = AF_INET;
		ttSock.sin_port = htons(TIPTAP_PORT);

		//Set socket file handle and check for error
		if((sock = socket(ttSock.sin_family, SOCK_STREAM, 0)) == -1){
			perror("FAILED: socket call");
			return 1;
		}
		
		//Connect to the server
		if((connect(sock, (const struct sockaddr *)&ttSock, sizeof(struct sockaddr_in))) == -1){
			perror("FAILED: connection call");
			return 1;
		}
		
		//Set write instruction to appropriate number of bytes to TT_POWERON
		writeInsn = calloc(3, sizeof(uint16_t));

		//Make write instruction to send to server
		makeWriteInsn(insn, writeInsn, 0);

		//Send write instruction and check number of bytes have been written
		if((write(sock, writeInsn, 6)) != 6){
			perror("FAILED: write instruction");
			return 1;
		}

		//Set read instruction to appropriate number of bytes to TT_POWERON
		readInsn = calloc(4, sizeof(uint16_t));

		//Send read instruction and check number of bytes have been read
		if((read(sock, readInsn, 8)) != 8){
			perror("FAILED: read instruction");
			return 1;
		}

		//Check return value of read instruction
		if(((ntohs(readInsn[0]))) != 0){
			perror("FAILED: return value of read not 0");
			return 1;
		}

		//Set the buffer equal to the data buffer sent back from read (these will be the x and y print dimensions
		//that are returned)
		((uint16_t*)buf)[0] = readInsn[2];
		((uint16_t*)buf)[1] = readInsn[3];
	}

	//If the flag is to probe the tiptap printer
	else if(flag == ((uint8_t)TTFLAG_PROBE)){
		uint16_t dist = 0;	//Variable for getting distance(which will represent number of bytes)
		dist = returnDist(insn);

		int distInt = (int) dist;
		distInt = signextend_9bit(distInt);

		if(distInt == 0)
			distInt = 1;

		//Set write instruction to appropriate number of bytes to TTFLAG_PROBE
		writeInsn = calloc(3, sizeof(uint16_t));

		//Make write instruction to send to server
		makeWriteInsn(insn, writeInsn, 0);

		//Send write instruction to appropriate number of bytes to TTFLAG_PROBE
		if((write(sock, writeInsn, 6)) != 6){
			perror("FAILED: write instruction");
			return 1;
		}

		//Set read instruction to appropriate number of bytes to TTFLAG_PROBE
		readInsn = calloc(2 + abs(distInt), sizeof(uint16_t));

		//Send read instruction and check number of bytes have been read
		if((read(sock, readInsn, (4 + (2 * abs(distInt))))) != (4 + (2 * abs(distInt)))){
			perror("FAILED: read instruction probe");
			return 1;
		}

		//Check return value of read instruction
		if(((ntohs(readInsn[0]))) != 0){
			perror("FAILED: return value of read not 0");
			return 1;
		}

		//Sets buffer for distance fields of probe
		int i = 0;

		for(i = 0; i < ((int)(abs(distInt))); i++)
			((uint16_t*)buf)[i] = readInsn[i + 2];

		//Set variables to 0
		i = 0;
		dist = 0;
		distInt = 0;
	}

	//If the opcode is to power off the tiptap printer
	else if(opcode == ((uint8_t)TT_POWEROFF)){
		//Set write instruction to appropriate number of bytes
		writeInsn = calloc(3, sizeof(uint16_t));
		
		//Make write instruction to send to server
		makeWriteInsn(insn, writeInsn, 0);

		//Send write instruction and check number of bytes have been written
		if((write(sock, writeInsn, 6)) != 6){
			perror("FAILED: write instruction");
			return 1;
		}

		//Set read instruction to appropriate number of bytes
		readInsn = calloc(2, sizeof(uint16_t));

		//Send read instruction and check number of bytes have been read
		if((read(sock, readInsn, 4)) != 4){
			perror("FAILED: read instruction");
			return 1;
		}

		//Check return value of read instruction
		if(((ntohs(readInsn[0]))) != 0){
			perror("FAILED: return value of read not 0");
			return 1;
		}

		//Close socket and check for errors
		if((close(sock)) != 0){
			perror("FAIELD: close failed");
			return 1;
		}

		sock = -1;	//Reset socket to negative one
	}

	//If any other instruction and the socket fd has been set (i.e. we powered on tiptap printer)
	else if(sock != -1){
		//If we are not printing
		if(flag != ((uint8_t)TTFLAG_EXTRUDE)){
			//Set write instruction to appropriate number of bytes 
			writeInsn = calloc(3, sizeof(uint16_t));

			//Make write instruction to send to server
			makeWriteInsn(insn, writeInsn, 0);

			//Send write instruction and check number of bytes have been written
			if((write(sock, writeInsn, 6)) != 6){
				perror("FAILED: write instruction");
				return 1;
			}
		}

		else{
			uint16_t dist = 0;	//Variable for getting distance (which will represent number of bytes)
			
			dist = returnDist(insn);

			//Use sign extension function
			int distInt = (int) dist;
			distInt = signextend_9bit(distInt);
	
			if(distInt == 0)
				distInt = 1;
			
			//Set write instruction to appropriate number of bytes to TTFLAG_EXTRUDE
			writeInsn = calloc((6 + abs(distInt)), sizeof(uint8_t));

			//Make write instruction to send to server
			makeWriteInsn(insn, writeInsn, abs(distInt));
			makeWriteInsnPrnt(buf, ((uint8_t*)writeInsn), abs(distInt));

			//Send write instruction and check number of bytes have been written
			if((write(sock, writeInsn, (6 + abs(distInt)))) != (6 + abs(distInt))){
				perror("FAILED: write instruction");
				return 1;
			}

			//Set variables to 0
			dist = 0;
			distInt = 0;
		}

		//Set read instruction to appropriate number of bytes
		readInsn = calloc(2, sizeof(uint16_t));

		//Send read instruction and check number of bytes have been read
		if((read(sock, readInsn, 4)) != 4){
			perror("FAILED: read instruction");
			return 1;
		}
		
		//Check return value of read instruction
		if(((ntohs(readInsn[0]))) != 0){
			perror("FAILED: return value of read not 0");
			return 1;
		}
	}

	//Free write and read and null terminate
	free(writeInsn);	
	free(readInsn);
	writeInsn = NULL;
	readInsn = NULL;

	//Set variables equal to 0
	opcode = 0;	
	flag =0 ;

	return 0;
}

//uint8_t returnOpCode: takes instruction and returns opcode of instruction
uint8_t returnOpCode(uint32_t insn){
	uint8_t opcode = 0;

	//Returns bits 27-31 of instruction (i.e. the opcode bits)
	opcode |= (insn >> 27);

	return opcode;
}

//uint8_t returnFlag: takes instructions and returns flag of instruction
uint8_t returnFlag(uint32_t insn){
	uint8_t flag =0;

	//Returns bits 10-13 of instruction (i.e. the flag bits)
	flag |= (insn << 18) >> 28;

	return flag;
}

//uint16_t returnDist: takes instruction and returns distance of instruction
uint16_t returnDist(uint32_t insn){
	uint16_t dist = 0;

	//Returns bits 14-22 of instruction (i.e. the distance bits)
	dist |= (insn << 9) >> 23;

	return dist;
}

//makeWriteInsn: Creates write instruction for writeInsn ptr
void makeWriteInsn(uint32_t insn, uint16_t *writeInsn, size_t numBytes){
	//Set the first four bytes of write instruction to properly converted insn bits
	((uint32_t*)writeInsn)[0] = htonl(insn);

	//Set the next 2 bytes of write instruction to properly converted numBytes bits
	writeInsn[2] = htons(numBytes);
}

//makeWriteInsnPrnt: Writes the buffer bits into the writeInsnPrnt
void makeWriteInsnPrnt(void *buffer, uint8_t *writeInsnPrnt, size_t numBytes){
	int i = 0;

	//Set the last few bytes of writeInsnPrnt to buffer
	for(i = 0; i < ((int)numBytes); i++)
		writeInsnPrnt[6 + i] = ((uint8_t*)buffer)[i];

	i = 0;
}
